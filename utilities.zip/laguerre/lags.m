function [varargout]=lags(n)

% x=lags(n,alp) returns n Laguerre-Gauss points 
%  [x,w]= glags(n,alp)  returns n  Laguerre-Gauss points and weights
%  [x,w,wf]=glagsrd(n,alp) also returns the weights (in wf) associated with Laguerre
%  function approach (see (7.34) of the book). 
%  Eigenmethod is used for computing nodes.
% Use: lapoly( ); lafun();
%  Last modified on Decemeber 21, 2011


J=diag(2*[0:n-1]+1)+diag(-[1:n-1],1)+diag(-[1:n-1],-1);  % (7.38) of the book
r = sort(eig(sparse(J)));               % Compute eigenvalues

varargout{1}=r;
if nargout==1, return; end;

% Compute the weights (7.32) of the book 
y=lapoly(n-1,r);
varargout{2}=r./(n^2*y.^2);  

if nargout==2, return; end;

z=lafun(n-1,r);
varargout{3}=r./(n^2*z.^2);  % output weights related to Laguerre function approach.

return
