% The function s=lafdisctran(n,x,p,iflag) performs the discrete transforms (in Laguerre functions) 
% between the physical space (i.e., physical values) and frequence space
% (Laguerre function expansions) at the Laguerre-Gauss-Radau points
% Input:
%  n, x,w--- number of Laguerre-Gauss-Radau points in x, where (x,w) can be computed by
%          [x,wl,w]=lagsrd(n). Note: x,w are column vectors (w is associated with Laguerre function approach)  
%  iflag==0--- forward transform  
%    p--- (input) physical values at collocation points
%    s--- (output) expansion coefficients 
%  iflag not= 0--- backward transform  
%    p--- (input) expansion coefficients 
%    s--- (output) physical values at collocation points 
%
%  See Page 246 of the book: J. Shen, T. Tang and L. Wang, Spectral Methods:
%  Algorithms, Analysis and Applications, Springer Series in Compuational
%  Mathematics, 41, Springer, 2011. 
%  Use the function: lafunm()   
%  Last modified on December 22, 2011


function s=lafdisctran(n,x,w,p,iflag)
 T=lafunm(n-1,x); % compute the Laguerre functions to order n-1. Note: T(i,j)=L_i(x_j) 
 if iflag==0, 
     s=T*(p.*w); % see Page 250
     return;
 end
 
 s=T'*p;  
 return
 
 

