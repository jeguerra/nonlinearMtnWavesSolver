function [varargout]=hepoly(n,x)
  
% hepoly  Hermite polynomial of degree n
    % y=hepoly(n,x) returns the Hermite polynomial of degree n at x
    % The degree should be a nonnegative integer 
    % [dy,y]=hepoly(n,x) also returns the first-order 
    %  derivative of the Hermite polynomial in dy
% Last modified on Decemeber 22, 2011      

if nargout==1,       
 if n==0, varargout{1}=ones(size(x));  return; end;
 if n==1, varargout{1}=2*x; return; end;

  polylst=ones(size(x)); poly=2*x;     
  for  k=1:n-1,
	  polyn=2*x.*poly-2*k*polylst;  % H_{k+1}=2*x H_k-2k H_{k-1}
      polylst=poly; poly=polyn;	
  end;
    varargout{1}=poly;
end

if nargout==2,
  if n==0, varargout{2}=ones(size(x));  varargout{1}=zeros(size(x)); return; end;
  if n==1, varargout{2}=2*x; varargout{1}=2*ones(size(x)); return; end;

   polylst=ones(size(x)); poly=2*x; 
   for k=1:n-1,
      polyn=2*x.*poly-2*k*polylst;               % H_{k+1}=2*x H_k-2k H_{k-1}
	  pdern=2*(k+1)*poly;	                	 % H_{k+1}'=2*(k+1)*H_k;  see (7.67)
	  polylst=poly;  poly=polyn; 
   end;
      varargout{2}=poly;  varargout{1}=pdern;
 end;
 
 return;
  
  
    
         
    
    
   


    

  
     
	
