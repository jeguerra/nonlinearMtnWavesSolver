function [varargout]= hegs(n)

%  The function x=hegs(n) computes n nodes of the Hermite-Gauss  quadrature.
%     [x,w]=hegs(n) also returns the weights in w.
%     [x,w,wf]=hegs(n) also returns the weights assocaited with Hermite 
%           function approach in wf.
%  Use: hepoly();
%  Eigenvalue method is used for computing nodes.
% Last modified on December 22, 2011.


J=diag(sqrt([1:n-1]/2),1)+diag(sqrt([1:n-1]/2),-1);  % see (7.84)
r =sort(eig(sparse(J)));              % Compute eigenvalues

varargout{1}=r;

if nargout==1,  return; end; 

y=hepolyn(n-1,r);                                    
varargout{2}=sqrt(pi)./(n*y.^2);       % Output the weights

if nargout==2,  return; end;

y=hefun(n-1,r);
varargout{3}=1./(n*y.^2);       % Output the weights (laguerre function approach)
