% Perform differentiation in Hermite function expansions in the frequency space  
% See Page 262 of the book: J. Shen, T. Tang and L. Wang, Spectral Methods:
%  Algorithms, Analysis and Applications, Springer Series in Compuational
%  Mathematics, 41, Springer, 2011. 
% 
%  duh=hefreqdiff(n,uh) returns the Hermite function expansion coefficient of the
%   1st-order derivative of u, if the expansion coefficients of u are given by uh, 
%   (which can be computed by the function hefdisctran()). 
%  Note: this function combined with the discrete Hermite function transform
%  hefdisctran() can be used for spectral differentiation in the frequency
%  space. One difference with the usual case (like Laguerre function approach)
%   is that differentiation adds one degree to the basis, so we need to increase 
%   n to n+1, when we use the routine hefdisctran() to obtain the physical values of u' 
%
%  Last modified on December 22, 2011

function duh=heffreqdiff(n,uh)
   
  duh=zeros(length(uh)+1,1); 
  duh(end)=-sqrt(n/2)*uh(end); 
  duh(end-1)=-sqrt((n-1)/2)*uh(end-1); 
for k=n-2:-1:1
 duh(k+1)=sqrt(0.5*(k+1))*uh(k+2)-sqrt(0.5*k)*uh(k) ;     % Use the backward formula (7.96)
end
 duh(1)=sqrt(0.5)*uh(2);  
return

