function [varargout]=hefun(n,x)
  
% hefun  Hermite funcation of degree n defined by c_n e^{-x^2/2}*hepoly(n,x)
%        c_n=1/(pi^(1/4)(2^n n!)^(1/2)). Then the Hermite functions are
%        orthonormal with respect to a unit weight function (see (7.71) of the book).
    % y=lafun(n,x) returns the Laguerre function of degree n at x
    % The degree should be a nonnegative integer 
    % The argument x >0; 
    % [dy,y]=lafun(n,x) also returns the first-order 
    %  derivative of the Laguerre function in dy
% Last modified on Decemeber 22, 2011       

   cst=1/sqrt(sqrt(pi));   
if nargout==1
   if n==0, varargout{1}=cst*exp(-x.^2/2);  return; end;
   if n==1, varargout{1}=cst*sqrt(2)*x.*exp(-x.^2/2); return; end;

   polylst=cst*exp(-x.^2/2);	poly=cst*sqrt(2)*x.*exp(-x.^2/2);     
   for k=1:n-1
	  polyn=sqrt(2/(k+1))*x.*poly-sqrt(k/(k+1))*polylst;  % see (7.73)
      polylst=poly; poly=polyn;	
   end;
   varargout{1}=poly;
end;

if nargout==2
  if n==0, varargout{2}=cst*exp(-x.^2/2);  varargout{1}=-cst*x.*exp(-x.^2/2); return; end;
  if n==1, varargout{2}=cst*sqrt(2)*x.*exp(-x.^2/2); 
      varargout{1}=cst*sqrt(2)*(1-x.^2).*exp(-x.^2/2); return; end;

  polylst=cst*exp(-x.^2/2);	poly=cst*sqrt(2)*x.*exp(-x.^2/2);     
   for k=1:n-1
      polyn=sqrt(2/(k+1))*x.*poly-sqrt(k/(k+1))*polylst;  % see (7.73)
      pdern=sqrt(2*(k))*poly-x.*polyn;    % see (7.75)      
      polylst=poly; poly=polyn;	      
   end;
      varargout{2}=poly;  varargout{1}=pdern;
 end;
 
 return
     
         
    
    
   


    

  
     
	
