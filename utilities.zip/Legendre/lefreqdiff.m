% Perform differentiation in frequency space. 
% See Page 105 of the book: J. Shen, T. Tang and L. Wang, Spectral Methods:
%  Algorithms, Analysis and Applications, Springer Series in Compuational
%  Mathematics, 41, Springer, 2011. 
% 
%  duh=lefreqdiff(n,uh) returns the Legendre expansion coefficient of the
%   1st-order derivative of u, if the expansion coefficients of u are given by uh, 
%   (which may be computed by the function ledisctran()). 
%  Note: this function combined with the discrete Legendre transform
%  ledisctran() can be used for spectral differentiation in frequency
%  space. It is an important ingredient for Legendre-Spectral-Galerkin
%  method. 
%  Last modified on August 31, 2011

function duh=lefreqdiff(n,uh)
 duh=zeros(size(uh)); duh(n)=0; duh(n-1)=(2*n-3)*uh(n); 
for k=n-1:-1:2,
 duh(k-1)=(2*k-3)*(uh(k)+duh(k+1)/(2*k+1));     % Use the backward formula (3.206)
end
return

