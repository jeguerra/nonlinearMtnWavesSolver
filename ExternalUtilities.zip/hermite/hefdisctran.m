% The function s=hefdisctran(n,x,p,iflag) performs the discrete transforms (in Hermite functions) 
% between the physical space (i.e., physical values) and frequency space
% (Hermite function expansions) at the Hermite points
% Input:
%  n, x,w--- number of Hermite-Gauss points in x, where (x,w) can be computed by
%          [x,wl,w]=hegs(n). Note: x,w are column vectors (w is associated with Laguerre function approach)  
%  iflag==0--- forward transform  
%    p--- (input) physical values at collocation points
%    s--- (output) expansion coefficients 
%  iflag not= 0--- backward transform  
%    p--- (input) expansion coefficients 
%    s--- (output) physical values at collocation points 
%
%  Use the function: hefunm()   
%  Last modified on December 22, 2011


function s=hefdisctran(n,x,w,p,iflag)
 T=hefunm(n-1,x); % compute the Hermite functions to order n-1. Note: T(i,j)=H_i(x_j) 
 if iflag==0
     s=T*(p.*w); % see Page 261 of the book 
     return;
 end
 
 s=T'*p;  
 return
 
 

