% D=hegsdiff(n,x) returns the first-order differentiation matrix of size
% n by n, at the Hermite-Gauss points x, which can be computed by 
% x=lags(n), associated with Laguerre function approach  
% Use the function: hepolyn() 
% Last modified on December 22, 2011

function D=hegsdiff(n,x)
if n==0, D=[]; return; end;
xx=x;y=hepolyn(n-1,xx); nx=size(x); 
if nx(2)>nx(1), y=y'; xx=x'; end;  %% xx, y are column-n vectors
  D=(xx./y)*y'-(1./y)*(xx.*y)';  %% see (7.92) but use the normalized Hermite polynomial
  D=D+eye(n);                    % add the identity matrix so that 1./D can be operated                                     
  D=1./D; 
  D=D-eye(n); D=D+diag(xx');  % update the diagonal entries  
   
  return; 
 