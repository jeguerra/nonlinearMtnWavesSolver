function [varargout]=hepolyn(n,x)
  
    % The function y=hepolyn(n,x) computes the values of  normalized Hermite polynomial
    %        of degree n,at x.
    %  Normalized by the factor 1/sqrt(2^n n!)
    % Last modified on December 21, 2011 
    
if nargout==1,
  if n==0, varargout{1}=ones(size(x));  return; end;
  if n==1, varargout{1}=sqrt(2)*x; return; end;
    
  polylst=ones(size(x)); poly=sqrt(2)*x;     
  for  k=1:n-1,
   polyn=sqrt(2/(k+1))*x.*poly-sqrt(k/(k+1))*polylst;
   polylst=poly; poly=polyn;	
  end;
   varargout{1}=poly;
end;
        
   
if nargout==2,
  if n==0, varargout{2}=ones(size(x));  varargout{1}=zeros(size(x)); return; end;
  if n==1, varargout{2}=sqrt(2)*x; 
      varargout{1}=sqrt(2); return; end;

  polylst=ones(size(x));	poly=sqrt(2)*x;     
   for k=1:n-1,
      polyn=sqrt(2/(k+1))*x.*poly-sqrt(k/(k+1))*polylst;  
      pdern=sqrt(2*(k+1))*poly-x.*polyn;    
      polylst=poly; poly=polyn;	      
   end;
      varargout{2}=poly;  varargout{1}=pdern;
 end;
 
 return
 
 
   


    

  
     
	
