% Perform differentiation in Laguerre function expansions in the frequency space  
% See Page 253 of the book: J. Shen, T. Tang and L. Wang, Spectral Methods:
%  Algorithms, Analysis and Applications, Springer Series in Compuational
%  Mathematics, 41, Springer, 2011. 
% 
%  duh=lefreqdiff(n,uh) returns the Laguerre function expansion coefficient of the
%   1st-order derivative of u, if the expansion coefficients of u are given by uh, 
%   (which can be computed by the function lafdisctran()). 
%  Note: this function combined with the discrete Laguerre function transform
%  lafdisctran() can be used for spectral differentiation in the frequency
%  space.  
%  Last modified on December 22, 2011

function duh=laffreqdiff(n,uh)
 duh=zeros(size(uh)); duh(n)=-0.5*uh(n); 
for k=n-1:-1:1,
 duh(k)=duh(k+1)-0.5*(uh(k)+uh(k+1)) ;     % Use the backward formula (7.56)
end
return

